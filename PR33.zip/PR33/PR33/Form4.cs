﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Security.Cryptography;

namespace PR33
{
    public partial class Form4 : Form
    {
        int d = 0;
        int c = 0;
        double r = 25;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            timer1.Interval = 5;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Top = pictureBox1.Top + d;
            if (pictureBox1.Top >= 300 || pictureBox1.Top <= r)
            {
                d = -d;
                if (pictureBox1.Top >= 300)
                {
                    r = r * 1.75;
                }
                if (pictureBox1.Top <= r + 10)
                {
                    for (int i = 0; i < 15; i++)
                    {
                        pictureBox1.Top = pictureBox1.Top - 1;
                        Thread.Sleep(13);
                    }
                }
                if (pictureBox1.Top <= r)
                {
                    Thread.Sleep(75);
                    for (int i = 0; i < 15; i++)
                    {
                        pictureBox1.Top = pictureBox1.Top + 1;
                        Thread.Sleep(13);
                    }
                }
            }
            if (r >= 200)
            {
                c = 0;
                d = 0;
            }
            pictureBox1.Left = pictureBox1.Left + c;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Left = 23;
            pictureBox1.Top = 69;
            d = 6;
            c = 1;
            r = 25;
        }
    }
}
